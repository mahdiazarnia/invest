<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class Referral extends Model
{
    protected static $table = 'hyiplab_referrals';
}
