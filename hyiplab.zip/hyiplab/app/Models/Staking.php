<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class Staking extends Model
{
    protected static $table = 'hyiplab_stakings';
}
