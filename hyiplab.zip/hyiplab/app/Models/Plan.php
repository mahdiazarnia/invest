<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class Plan extends Model
{
    protected static $table = 'hyiplab_plans';
}
