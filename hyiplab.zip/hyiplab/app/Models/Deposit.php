<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class Deposit extends Model
{
    protected static $table = 'hyiplab_deposits';
}
