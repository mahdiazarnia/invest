<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class Transaction extends Model
{
    protected static $table = 'hyiplab_transactions';
}
