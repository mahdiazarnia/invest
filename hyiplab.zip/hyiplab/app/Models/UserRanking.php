<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class UserRanking extends Model
{
    protected static $table = 'hyiplab_user_rankings';
}