<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class Withdrawal extends Model
{
    protected static $table = 'hyiplab_withdrawals';
}
