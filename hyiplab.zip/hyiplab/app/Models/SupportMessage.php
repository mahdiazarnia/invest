<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class SupportMessage extends Model
{
    protected static $table = 'hyiplab_support_messages';
}
