<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class TimeSetting extends Model
{
    protected static $table = 'hyiplab_time_settings';
}
