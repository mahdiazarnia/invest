<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class PoolInvest extends Model
{
    protected static $table = 'hyiplab_pool_invests';
}
