<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class GatewayCurrency extends Model
{
    protected static $table = 'hyiplab_gateway_currencies';
}
