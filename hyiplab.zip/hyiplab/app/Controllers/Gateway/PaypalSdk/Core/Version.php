<?php

namespace Hyiplab\Controllers\Gateway\PaypalSdk\Core;

class Version
{
    const VERSION = "1.0.1";
}
