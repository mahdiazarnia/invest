
<?php

namespace App\Includes\Sms;

class IppanelSms
{
    protected $username;
    protected $password;
    protected $from;

    public function __construct($config)
    {
        $this->username = $config['username'] ?? 'YOUR_USERNAME';
        $this->password = $config['password'] ?? 'YOUR_PASSWORD';
        $this->from = $config['from'] ?? 'YOUR_SENDER_NUMBER';
    }

    public function send($to, $message)
    {
        $payload = [
            "username" => $this->username,
            "password" => $this->password,
            "from" => $this->from,
            "to" => [$to],
            "text" => $message
        ];

        $ch = curl_init("https://rest.ippanel.com/v1/messages");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err) {
            throw new \Exception("IPPANEL Error: " . $err);
        }

        $result = json_decode($response, true);
        return $result;
    }
}
