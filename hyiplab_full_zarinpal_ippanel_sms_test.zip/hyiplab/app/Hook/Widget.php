<?php

namespace Hyiplab\Hook;

class Widget{
    public function loadWidget()
    {
        //WP Widgets will go here
    }
}