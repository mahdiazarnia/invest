
<?php

namespace App\Controllers;

use App\BackOffice\Facade\Session;
use App\Includes\Gateway\PaymentGateway;
use App\Models\Payment;

class ZarinpalPaymentController
{
    public function initiate()
    {
        $amount = $_POST['amount'];
        $user_id = $_SESSION['user_id'] ?? null;
        $merchant_id = 'YOUR_MERCHANT_ID';
        $callback_url = url('zarinpal/verify');
        $description = "پرداخت توسط درگاه زرین‌پال";

        $data = [
            "merchant_id" => $merchant_id,
            "amount" => $amount * 10,
            "callback_url" => $callback_url,
            "description" => $description,
            "metadata" => ["email" => "user@example.com", "mobile" => "09123456789"]
        ];

        $jsonData = json_encode($data);
        $ch = curl_init('https://api.zarinpal.com/pg/v4/payment/request.json');
        curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest API v4');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

        $result = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        $result = json_decode($result, true);

        if (!empty($result['data']) && empty($result['errors'])) {
            $_SESSION['zarinpal_amount'] = $amount;
            $_SESSION['zarinpal_authority'] = $result['data']['authority'];
            header('Location: https://www.zarinpal.com/pg/StartPay/' . $result['data']['authority']);
            exit();
        } else {
            echo "خطا در اتصال به زرین‌پال";
            print_r($result['errors']);
        }
    }

    public function verify()
    {
        $merchant_id = 'YOUR_MERCHANT_ID';
        $authority = $_GET['Authority'];
        $amount = $_SESSION['zarinpal_amount'] * 10;

        if ($_GET['Status'] == 'OK') {
            $data = [
                "merchant_id" => $merchant_id,
                "amount" => $amount,
                "authority" => $authority
            ];
            $jsonData = json_encode($data);
            $ch = curl_init('https://api.zarinpal.com/pg/v4/payment/verify.json');
            curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest API v4');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

            $result = curl_exec($ch);
            $err = curl_error($ch);
            curl_close($ch);
            $result = json_decode($result, true);

            if (!empty($result['data']) && $result['data']['code'] == 100) {
                echo "پرداخت موفق بود. کد پیگیری: " . $result['data']['ref_id'];
                // TODO: ثبت در دیتابیس یا فعال‌سازی سرویس
            } else {
                echo "پرداخت ناموفق بود";
            }
        } else {
            echo "پرداخت لغو شد";
        }
    }
}
