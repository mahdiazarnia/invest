
<?php

namespace App\Controllers\Admin;

use App\Notify\Sms;

class SmsTestController
{
    public function index()
    {
        view('admin.sms.test_sms');
    }

    public function send()
    {
        $to = $_POST['mobile'];
        $message = $_POST['message'];

        try {
            $sms = new Sms();
            $sms->mobile = $to;
            $sms->send($message);

            echo "<div style='color:green'>پیامک با موفقیت ارسال شد.</div>";
        } catch (\Exception $e) {
            echo "<div style='color:red'>خطا در ارسال پیامک: " . $e->getMessage() . "</div>";
        }
    }
}
