<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class WithdrawMethod extends Model
{
    protected static $table = 'hyiplab_withdraw_methods';
}
