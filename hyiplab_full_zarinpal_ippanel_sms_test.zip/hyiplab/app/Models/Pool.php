<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class Pool extends Model
{
    protected static $table = 'hyiplab_pools';
}
