<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class StakingInvest extends Model
{
    protected static $table = 'hyiplab_staking_invests';
}
