<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class Extension extends Model
{
    protected static $table = 'hyiplab_extensions';
}
