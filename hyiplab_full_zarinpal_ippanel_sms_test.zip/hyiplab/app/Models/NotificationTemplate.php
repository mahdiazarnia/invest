<?php

namespace Hyiplab\Models;

use Hyiplab\BackOffice\Database\Model;

class NotificationTemplate extends Model
{
    protected static $table = 'hyiplab_notification_templates';
}
