
<div class="card">
    <div class="card-header">
        <h5 class="card-title">تست ارسال پیامک</h5>
    </div>
    <div class="card-body">
        <form method="post" action="/admin/sms/test/send">
            <div class="form-group">
                <label>شماره موبایل</label>
                <input type="text" name="mobile" class="form-control" placeholder="09xxxxxxxxx" required>
            </div>
            <div class="form-group">
                <label>متن پیام</label>
                <textarea name="message" class="form-control" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary mt-2">ارسال پیامک</button>
        </form>
    </div>
</div>
